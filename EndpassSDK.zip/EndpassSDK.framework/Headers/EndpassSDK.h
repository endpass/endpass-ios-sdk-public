//
//  EndpassSDK.h
//  EndpassSDK
//
//  Created by Александр on 20.04.2020.
//  Copyright © 2020 Александр. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for EndpassSDK.
FOUNDATION_EXPORT double EndpassSDKVersionNumber;

//! Project version string for EndpassSDK.
FOUNDATION_EXPORT const unsigned char EndpassSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EndpassSDK/PublicHeader.h>


